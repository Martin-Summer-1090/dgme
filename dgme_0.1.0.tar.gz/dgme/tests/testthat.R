library(testthat)
library(dgme)

test_check("dgme")
