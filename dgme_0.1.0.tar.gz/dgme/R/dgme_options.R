#' Get or Set Package-Wide Defaults
#'
#' Get or set package-wide defaults for output directories and visual style.
#'
#' @param fig_dir Character. Default directory for saved figures.
#' @param tab_dir Character. Default directory for saved tables.
#' @param tikz_dir Character. Default directory for saved TikZ files.
#' @param theme Character. Default plot theme ("paper" or "presentation").
#' @param device Character. Default graphics device.
#' @param width Numeric. Default plot width in inches.
#' @param height Numeric. Default plot height in inches.
#' @param ... Additional options (ignored).
#'
#' @return If called with no arguments, a named list of current settings.
#'   Otherwise sets the specified options and returns previous values invisibly.
#' @export
dgme_options <- function(fig_dir = NULL, tab_dir = NULL, tikz_dir = NULL,
                         theme = NULL, device = NULL, width = NULL,
                         height = NULL, ...) {

  opts <- list(
    fig_dir  = fig_dir,
    tab_dir  = tab_dir,
    tikz_dir = tikz_dir,
    theme    = theme,
    device   = device,
    width    = width,
    height   = height
  )
  opts <- opts[!vapply(opts, is.null, logical(1))]

 if (length(opts) == 0L) {
    # Return current settings
    return(list(
      fig_dir  = getOption("dgme.fig_dir",  "figures/"),
      tab_dir  = getOption("dgme.tab_dir",  "tables/"),
      tikz_dir = getOption("dgme.tikz_dir", getOption("dgme.fig_dir", "figures/")),
      theme    = getOption("dgme.theme",    "paper"),
      device   = getOption("dgme.device",   "pdf"),
      width    = getOption("dgme.width",    6),
      height   = getOption("dgme.height",   5)
    ))
  }

  # Set new options and return old values
  old <- list()
  for (nm in names(opts)) {
    key <- paste0("dgme.", nm)
    old[[nm]] <- getOption(key)
    args <- stats::setNames(list(opts[[nm]]), key)
    do.call(options, args)
  }
  invisible(old)
}
