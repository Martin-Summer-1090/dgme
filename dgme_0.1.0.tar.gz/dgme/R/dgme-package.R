#' dgme: Dubey-Geanakoplos Monetary Equilibria
#'
#' Compute and visualise monetary equilibria for 2-household, 2-good economies
#' based on the Dubey-Geanakoplos (1992, 2003, 2006) model.
#'
#' @section Pipeline:
#' The package centres on a three-stage pipeline:
#' \enumerate{
#'   \item \code{\link{dgme_parametrize}}: specify exogenous parameters.
#'   \item \code{\link{dgme_solve}}: compute equilibria for one or more model
#'     variants.
#'   \item Visualise and tabulate (coming in v0.2.0).
#' }
#'
#' @docType package
#' @name dgme-package
"_PACKAGE"
